export { default as SM6_Bonnet_Transparent } from "./SM6_Bonnet_Transparent";
export { default as SM6_Bumper_Transparent } from "./SM6_Bumper_Transparent";
export { default as SM6_Headlight_Transparent } from "./SM6_Headlight_Transparent";
export { default as SM6_TailLamp_Transparent } from "./SM6_TailLamp_Transparent";
export { default as SM6_Wheel_Transparent } from "./SM6_Wheel_Transparent";
