export { default as XM3_Body_Transparent } from "./XM3_Body_Transparent";
export { default as XM3_Bonnet_Transparent } from "./XM3_Bonnet_Transparent";
export { default as XM3_Bumper_Transparent } from "./XM3_Bumper_Transparent";
export { default as XM3_Headlight_Transparent } from "./XM3_Headlight_Transparent";
export { default as XM3_Taillamp_Transparent } from "./XM3_TailLamp_Transparent";
export { default as XM3_Wheel_Transparent } from "./XM3_Wheel_Transparent";
