export { default as Modern_garage_4k } from "./Modern_garage_4k";
