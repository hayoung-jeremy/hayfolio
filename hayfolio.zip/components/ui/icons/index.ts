export { default as Palette } from "./Palette";
