export const SCROLL_THRESHOLDS = {
  createYourEpicCar: {
    min: 0.00001,
    max: 0.45,
  },
  xperiencemor3: {
    min: 0.455,
  },
};
